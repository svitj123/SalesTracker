import { useState } from "react";
import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useReportStore } from "@/lib/store";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { ArrowUpRight, Timer, Target, ShoppingBag, Percent, Users, Calendar, Filter } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Dashboard() {
  const { getStats, getFilteredReports, getAgents } = useReportStore();
  const [selectedAgent, setSelectedAgent] = useState<string>("all");
  const [timeframe, setTimeframe] = useState<"week" | "month" | "all">("week");

  const agents = getAgents();
  const stats = getStats({ agent: selectedAgent, timeframe });
  const reports = getFilteredReports({ agent: selectedAgent, timeframe });

  // Prepare Chart Data
  const dailyData = reports.map(r => ({
    name: new Date(r.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
    Fix: r.fix,
    Mob: r.mob,
    Total: r.fix + r.mob,
    location: r.lokacija,
    agent: r.agent || 'Unknown'
  })).reverse();

  const locationPerformance = reports.reduce((acc, r) => {
    const existing = acc.find(i => i.name === r.lokacija);
    if (existing) {
      existing.value += (r.fix + r.mob);
    } else {
      acc.push({ name: r.lokacija, value: r.fix + r.mob });
    }
    return acc;
  }, [] as { name: string; value: number }[]).sort((a, b) => b.value - a.value).slice(0, 5);

  // Agent Leaderboard Data (only show if "All Agents" is selected)
  const agentLeaderboard = selectedAgent === "all" ? (() => {
    const agentStats: Record<string, number> = {};
    reports.forEach(r => {
      const name = r.agent || "Unknown";
      agentStats[name] = (agentStats[name] || 0) + r.fix + r.mob;
    });
    return Object.entries(agentStats)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  })() : [];


  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              {selectedAgent === 'all' ? 'Team Performance' : `${selectedAgent}'s Performance`}
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
             <div className="flex items-center gap-2 bg-card border rounded-lg p-1">
               <Filter className="h-4 w-4 ml-2 text-muted-foreground" />
               <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                <SelectTrigger className="w-[180px] border-0 shadow-none bg-transparent focus:ring-0">
                  <SelectValue placeholder="Select Agent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Agents</SelectItem>
                  {agents.map(agent => (
                    <SelectItem key={agent} value={agent}>{agent}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
             </div>

             <div className="flex items-center gap-2 bg-card border rounded-lg p-1">
                <Calendar className="h-4 w-4 ml-2 text-muted-foreground" />
                <Tabs value={timeframe} onValueChange={(v) => setTimeframe(v as "week" | "month" | "all")} className="w-[300px]">
                  <TabsList className="grid w-full grid-cols-3 bg-transparent h-8 p-0">
                    <TabsTrigger value="week" className="text-xs h-8 data-[state=active]:bg-primary/10 data-[state=active]:text-primary">This Week</TabsTrigger>
                    <TabsTrigger value="month" className="text-xs h-8 data-[state=active]:bg-primary/10 data-[state=active]:text-primary">This Month</TabsTrigger>
                    <TabsTrigger value="all" className="text-xs h-8 data-[state=active]:bg-primary/10 data-[state=active]:text-primary">All Time</TabsTrigger>
                  </TabsList>
                </Tabs>
             </div>
          </div>
        </div>

        {/* Key Stats Row */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
              <ShoppingBag className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalSales}</div>
              <p className="text-xs text-muted-foreground">
                {stats.totalFix} Fix + {stats.totalMob} Mob
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
              <Percent className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.salesSuccessRate.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground">
                Fix Sales / Contacts
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Hours</CardTitle>
              <Timer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalHours}h</div>
              <p className="text-xs text-muted-foreground">
                Field work duration
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Reports</CardTitle>
              <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.reportCount}</div>
              <p className="text-xs text-muted-foreground">
                Submitted in selected period
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <Card className="col-span-4">
            <CardHeader>
              <CardTitle>Sales Trend</CardTitle>
              <CardDescription>Performance breakdown</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <div className="h-[300px] w-full">
                {dailyData.length > 0 ? (
                   <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={dailyData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="name" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip 
                        contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                        itemStyle={{ color: 'hsl(var(--foreground))' }}
                        labelFormatter={(label, payload) => {
                           if (payload && payload.length > 0 && payload[0].payload.agent) {
                             return `${label} (${payload[0].payload.agent})`;
                           }
                           return label;
                        }}
                      />
                      <Legend />
                      <Bar dataKey="Fix" stackId="a" fill="#4ade80" radius={[0, 0, 4, 4]} />
                      <Bar dataKey="Mob" stackId="a" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground">No data available</div>
                )}
               
              </div>
            </CardContent>
          </Card>
          
          <Card className="col-span-3">
            <CardHeader>
              <CardTitle>
                {selectedAgent === 'all' ? 'Top Agents' : 'Top Locations'}
              </CardTitle>
              <CardDescription>
                {selectedAgent === 'all' ? 'By total sales volume' : 'Where sales are happening'}
              </CardDescription>
            </CardHeader>
            <CardContent>
               <div className="h-[300px] w-full">
                 {(selectedAgent === 'all' ? agentLeaderboard : locationPerformance).length > 0 ? (
                   <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={selectedAgent === 'all' ? agentLeaderboard : locationPerformance}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {(selectedAgent === 'all' ? agentLeaderboard : locationPerformance).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                         contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                         itemStyle={{ color: 'hsl(var(--foreground))' }}
                      />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                 ) : (
                    <div className="h-full flex items-center justify-center text-muted-foreground">No data available</div>
                 )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
